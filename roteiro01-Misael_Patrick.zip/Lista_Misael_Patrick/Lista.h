/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Lista.h
 * Author: aluno
 *
 * Created on 24 de Setembro de 2019, 09:52
 */

#ifndef LISTA_H
#define LISTA_H
#include "Produto.h"
class Lista {

public:
	Lista(int tamanho);
	void remove();
	void imprime();
	void imprimeProduto(int id);
	void insert(Produto& prod);
	int search(int codigo);
	Lista(const Lista& orig);
	virtual ~Lista();
private:
	int quantidade;
	int tamanho;
	Produto * lista;
	void shiftEnd(int index);
	void shiftFront(int index);
};

#endif /* LISTA_H */

