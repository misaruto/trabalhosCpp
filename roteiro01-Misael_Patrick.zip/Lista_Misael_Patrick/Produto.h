/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Produto.h
 * Author: aluno
 *
 * Created on 24 de Setembro de 2019, 09:38
 */

#ifndef PRODUTO_H
#define PRODUTO_H

class Produto {
public:
	Produto();
	void setEstoque(int estoque);
	int getEstoque() ;
	void setCusto(float custo);
	void getCusto();
	void setPreco(float preco);
	float getPreco();
	void setCodigo(int codigo);
	int getCodigo();
	
	void imprime();
	void preencherCampos();
	void copiarProduto (const  Produto& prod);
	
	
private:
	int codigo;
	float preco;
	float custo;
	int estoque;
};

#endif /* PRODUTO_H */

