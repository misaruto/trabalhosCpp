/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Produto.cpp
 * Author: aluno
 * 
 * Created on 24 de Setembro de 2019, 09:38
 */

#include "Produto.h"
#include <iostream>

using namespace std;

Produto::Produto() {
	this->codigo = -1;
	this->preco = 0.0;
	this->custo = 0.0;
	this->estoque = 0;
}

void Produto::imprime() {
	cout<< "____________________________________________________" << " \n";
	cout << "Codigo: "<< this->codigo << "\n";
	cout << "Preco: "<< this->preco << "\n";
	cout << "custo: "<< this->custo << "\n";
	cout << "Estoque:" << this->estoque << "\n";
	cout<< "____________________________________________________" << "\n";

}


void Produto::preencherCampos() {
	cout << "Informe o Codigo: ";
	cin>> this->codigo;
	cout << "informe o preco: ";
	cin >> this->preco;
	cout << "Informe o custo: ";
	cin >> this->custo;
	cout << "Informe o estoque:";
	cin >> this->estoque;

}

float Produto::getPreco(){
	return this->preco;
}
int Produto::getCodigo(){
	return this->codigo;
}
void Produto::copiarProduto(const Produto& prod){
	this->codigo = prod.codigo;
	this->preco = prod.preco;
	this->custo = prod.custo;
	this->estoque = prod.estoque;

}