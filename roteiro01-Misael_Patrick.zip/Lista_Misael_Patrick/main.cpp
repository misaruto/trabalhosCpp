/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: aluno
 *
 * Created on 24 de Setembro de 2019, 06:42
 */

#include <cstdlib>
#include <iostream>
#include "Lista.h"
#include "Produto.h"
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

	int ex;
	cout << "Digite o numero do exercicio(1 ou 2): ";
	cin >> ex;
	if (ex == 1)
	{
		Produto p1, p2;
		p1.preencherCampos();
		p2.preencherCampos();

		cout << "O produto que possui maior preco e:" << "\n";
		if(p1.getPreco() > p2.getPreco()){
			p1.imprime();
		}
		else{
			p2.imprime();
		}
	}
	else{
		int tamanho;
		cout << "Informe a quantidade de produtos: ";
		cin >> tamanho;
		Lista listaProdutos = Lista(tamanho);
		Produto prod = Produto();
		int opt=1;

		while(opt != 0){
			cout << "**** Menu **** \n1- Inserir Produto\n2- Apagar Produto\n3- Buscar produtos\n0- SAIR \n";
			cin >> opt;
			switch(opt){
				case 1:
				prod.preencherCampos();
				listaProdutos.insert(prod);

				break;
				case 2:
				listaProdutos.remove();
				break;
				case 3: 
				cout << "Informe o codigo do produto:";
				int id,codigo;
				cin >> codigo;
				id = listaProdutos.search(codigo);
				cout << endl << "O id do produto é:" << id <<endl;
				listaProdutos.imprimeProduto(id);
				break;
				default:
				cout <<"Opção invalida";
				break;
			}
		}
	}
	return 0;
}

