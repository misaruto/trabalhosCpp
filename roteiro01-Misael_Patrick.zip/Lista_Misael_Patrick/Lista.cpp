/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Lista.cpp
 * Author: aluno
 * 
 * Created on 24 de Setembro de 2019, 09:52
 */

#include "Lista.h"
#include "Produto.h"

#include <iostream>
using namespace std;
Lista::Lista(int tamanho) {
	this->tamanho = tamanho;
	this->quantidade = 0;
	this->lista = new Produto [this->tamanho];
}

void Lista::shiftEnd(int index){
	for (int i = quantidade; i < index; ++i)
	{
		lista[i].copiarProduto(lista[i-1]);
	}
}

void Lista::shiftFront(int index){
	for (int i = index; i < quantidade; ++i)
	{
		lista[i] = lista[i+1];
	}
}

int Lista::search(int codigo){
	if (this->quantidade > 0)
	{
		for (int i = 0; i < this->quantidade; ++i)
		{
			if (lista[i].getCodigo() == codigo)
			{
				return i;
			}
		}
		return -1;
	}
	else{
		cout << "Lista está vazia. \n";
	}
}

void Lista::insert(Produto &prod){
	int index;
	cout << "Informe a posição que deseja inserir o produto: ";
	cin >> index;
	if (this->quantidade < this->tamanho)
	{
		shiftEnd(index);
		lista[index].copiarProduto(prod);
		this->quantidade = this->quantidade +1;
	}
	else{
		cout << "A lista está cheia \n";
	}
}

void Lista::remove(){
	int codigo,index;
	cout << "Digite o codigo do Produto que deseja apagar:";
	cin >> codigo;
	index = search(codigo);
	shiftFront(index);
	cout << endl << "Produto apagado com sucesso." << endl;
}

void Lista::imprimeProduto(int id){
	lista[id].imprime();
}

Lista::Lista(const Lista& orig) {
}

Lista::~Lista() {
}

